# -*- coding: utf-8 -*-

from bincrafters import build_shared


def get_builder(**kwargs):
    return build_shared.get_builder(**kwargs)
