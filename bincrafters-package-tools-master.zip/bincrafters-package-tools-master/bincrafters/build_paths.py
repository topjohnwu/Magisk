# -*- coding: utf-8 -*-

BINCRAFTERS_REPO_URL = "https://api.bintray.com/conan/bincrafters/public-conan"
