package a;

import com.topjohnwu.magisk.SuRequestActivity;

public class m extends SuRequestActivity {
    /* stub */
}
