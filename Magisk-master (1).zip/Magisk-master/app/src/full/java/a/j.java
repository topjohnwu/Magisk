package a;

import com.topjohnwu.magisk.services.OnBootService;

public class j extends OnBootService {
    /* stub */
}
