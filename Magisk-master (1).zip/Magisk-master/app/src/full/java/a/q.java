package a;

import com.topjohnwu.magisk.MagiskManager;

public class q extends MagiskManager {
    /* stub */
}
