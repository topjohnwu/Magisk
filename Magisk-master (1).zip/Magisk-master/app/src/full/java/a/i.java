package a;

import com.topjohnwu.magisk.receivers.ShortcutReceiver;

public class i extends ShortcutReceiver {
    /* stub */
}
