package a;

import android.content.Context;
import android.util.AttributeSet;

import com.topjohnwu.magisk.components.AboutCardRow;

public class l extends AboutCardRow {
    /* stub */

    public l(Context context) {
        super(context);
    }

    public l(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public l(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
