package a;

import com.topjohnwu.magisk.receivers.GeneralReceiver;

public class h extends GeneralReceiver {
    /* stub */
}
