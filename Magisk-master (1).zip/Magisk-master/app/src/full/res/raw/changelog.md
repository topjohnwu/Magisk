## v6.1.0
- Introduce new downloading methods: no longer uses buggy system Download Manager
- Introduce many new notifications for better user experience
- Add support for Magisk v18.0
- Change application name to "Manager" after hiding(repackaging) to prevent app name detection
- Add built-in systemless hosts module (access in settings)
- Auto launch the newly installed app after hiding(repackaging) and restoring Magisk Manager
- Fix bug causing incomplete module.prop in modules to have improper UI